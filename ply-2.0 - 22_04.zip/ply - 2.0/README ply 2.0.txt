Versión 2.0

Reformateo de carpetas y nombres.

cambios a realizar:
	- Reconocimiento de inputs y outputs de nodos y de sink/source
	- Recnocimiento de la declaración con o sin anchura ()
	-Creación de un modelo compatible con los test para axi_acc_squares